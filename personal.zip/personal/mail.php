<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "db1";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    echo "conecto";
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $nombre = $_POST['nombre'];
    echo "$nombre";
    
    $email = $_POST['email'];
    echo "$email";

    $asunto = $_POST['asunto'];

    $mensaje = $_POST['mensaje'];

    mail("jabbo1998@gmail.com",$asunto,$mensaje,$email);
    
    $sql = "INSERT INTO table1 (id, nombre, email, asunto, mensaje)
    VALUES ('', '$nombre', '$email','$asunto','$mensaje' )";
    
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
    ?>
?>
